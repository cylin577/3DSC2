#include <3ds.h>
#include <stdio.h>

int main(int argc, char **argv)
{
    gfxInitDefault();

    int state = 0; // 0: Top Green, 1: Bottom Green, 2: Done

    while (aptMainLoop())
    {
        hidScanInput();
        u32 kDown = hidKeysDown();

        if (kDown & KEY_START) break; // Exit

        if (kDown & KEY_A) {
            state++;
            if (state > 1) state = 0; // Loop back
        }

        u8* fbTop = gfxGetFramebuffer(GFX_TOP, GFX_LEFT, NULL, NULL);
        u8* fbBot = gfxGetFramebuffer(GFX_BOTTOM, GFX_LEFT, NULL, NULL);

        if (state == 0) {
            // Top Green
            for(int i=0; i<400*240; i++) {
                fbTop[i*3+0] = 0;   // B
                fbTop[i*3+1] = 255; // G
                fbTop[i*3+2] = 0;   // R
            }
            // Bottom Black
            memset(fbBot, 0, 320*240*3);
        }
        else if (state == 1) {
            // Top Black
            memset(fbTop, 0, 400*240*3);
            // Bottom Green
            for(int i=0; i<320*240; i++) {
                fbBot[i*3+0] = 0;
                fbBot[i*3+1] = 255;
                fbBot[i*3+2] = 0;
            }
        }

        gfxFlushBuffers();
        gfxSwapBuffers();
        gspWaitForVBlank();
    }

    gfxExit();
    return 0;
}
